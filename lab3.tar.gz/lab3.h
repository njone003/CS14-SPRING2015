// Nicolas Jones
// 861169228
// 4/20/15
// incremental compilation

#include <iostream>
#include <cstdlib>
#include <stack>

using namespace std;

template <typename T>
class TwoStackFixed
{
    private:
        T *arr;
        int size;
        int maxtop; // partition of stacks in array
        int beg1; // beginning of stack 1 (grows forwards toward maxtop)
        int beg2; // beginning of stack 2 (grows inward toward maxtop)
    public:
       TwoStackFixed(int size, int maxtop) // constructor
       {
           this->size = size;
           arr = new T[size]; // create new array
           beg1 = -1;
           beg2 = size;
           this->maxtop = maxtop;
       }
     
       // Pushes a value to stack 1
       void pushStack1(T value)
       {
           // there is at least one empty space for new element
           if (beg1 < beg2 - 1)
           {
               beg1++;
               if (isFullStack1())
               {
                   cout << "Partition reached." << endl;
                   exit(1);
               }
               arr[beg1] = value;
           }
           else
           {
               cout << "Stack Overflow";
               exit(1);
           }
       }
     
       // Pushes a value to stack 2
       void pushStack2(T value)
       {
           // There is at least one empty space for new element
           if (beg1 < beg2 - 1)
           {
               beg2--;
               if (isFullStack2())
               {
                   cout << "Partition reached." << endl;
                   exit(1);
               }
               arr[beg2] = value;
           }
           else
           {
               cout << "Stack Overflow";
               exit(1);
           }
       }
     
       // Method to pop an element from first stack
       T popStack1()
       {
           if (beg1 >= 0 && !isEmptyStack1())
           {
              int x = arr[beg1];
              beg1--;
              return x;
           }
           else
           {
               cout << "Stack UnderFlow";
               exit(1);
           }
       }
     
       // Method to pop an element from second stack
       T popStack2()
       {
           if (beg2 < size && !isEmptyStack2())
           {
              int x = arr[beg2];
              beg2++;
              return x;
           }
           else
           {
               cout << "Stack UnderFlow";
               exit(1);
           }
       }
       
       void display()
       {
           for (int i = 0; i < size; ++i)
           {
               cout << arr[i] << ' ';
           }
           cout << endl;
       }
       
    private:
        // check whether first stack is full
        bool isFullStack1()
        {
            if (beg1 == maxtop)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether second stack is full
        bool isFullStack2()
        {
            if (beg2 == maxtop)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether first stack is empty
        bool isEmptyStack1()
        {
            if (beg1 == -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether second stack is empty
        bool isEmptyStack2()
        {
            if (beg2 == size)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
};

template <typename T>
class TwoStackOptimal
{
    private:
        T *arr;
        int size;
        int beg1; // beginning of stack 1 (grows forwards toward maxtop)
        int beg2; // beginning of stack 2 (grows inward toward maxtop)
    public:
       TwoStackOptimal(int size) // constructor
       {
           this->size = size;
           arr = new T[size]; // create new array
           beg1 = -1;
           beg2 = size;
       }
     
       // Pushes a value to stack 1
       void pushFlexStack1(T value)
       {
           // there is at least one empty space for new element
           if (beg1 < beg2 - 1)
           {
               beg1++;
               if (isFullStack1())
               {
                   cout << "Partition reached." << endl;
                   exit(1);
               }
               arr[beg1] = value;
           }
           else
           {
               cout << "Stack Overflow" << endl;
               exit(1);
           }
       }
     
       // Pushes a value to stack 2
       void pushFlexStack2(T value)
       {
           // There is at least one empty space for new element
           if (beg1 < beg2 - 1)
           {
               beg2--;
               if (isFullStack2())
               {
                   cout << "Partition reached." << endl;
                   exit(1);
               }
               arr[beg2] = value;
           }
           else
           {
               cout << "Stack Overflow" << endl;
               exit(1);
           }
       }
     
       // Method to pop an element from first stack
       T popFlexStack1()
       {
           if (beg1 >= 0 && !isEmptyStack1())
           {
              int x = arr[beg1];
              beg1--;
              return x;
           }
           else
           {
               cout << "Stack UnderFlow" << endl;
               exit(1);
           }
       }
     
       // Method to pop an element from second stack
       T popFlexStack2()
       {
           if (beg2 < size && !isEmptyStack2())
           {
              int x = arr[beg2];
              beg2++;
              return x;
           }
           
           else
           {
               cout << "Stack UnderFlow" << endl;
               exit(1);
           }
       }
       
       void display()
       {
           for (int i = 0; i < size; ++i)
           {
               cout << arr[i] << ' ';
           }
           cout << endl;
       }
       
    private:
        // check whether first stack is full
        bool isFullStack1()
        {
            if (beg1 == beg2)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether second stack is full
        bool isFullStack2()
        {
            if (beg2 == beg1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether first stack is empty
        bool isEmptyStack1()
        {
            if (beg1 == -1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        
        // check whether second stack is empty
        bool isEmptyStack2()
        {
            if (beg2 == size)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
};

// Tower of Hanoi function
template <typename T>
void showTowerStates(int n, stack<T>& A, stack<T>& B, stack<T>& C)
{
    if (n == 1)
    {
        C.push(A.top());
    }
    
    else
    {
        showTowerStates(n - 1, A, C, B);
        
        cout << "Moved " << n << " from peg A to peg B" << endl;
        
        C.push(A.top());
        
        showTowerStates(n - 1, B, A, C);
        
        cout << "Moved " << n << " from peg B to peg C" << endl;
    }
}
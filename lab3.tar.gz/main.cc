// Nicolas Jones
// 861169228
// 4/20/15
// incremental compilation

#include <iostream>
#include "lab3.h"

using namespace std;

int main()
{
    int size;
    // int partition;
    cout << "Size: ";
    cin >> size;
    // cout << "Partition: ";
    // cin >> partition;
    
    // TwoStackFixed<int> test(size, partition);
    
    // test.pushStack1(2);
    
    // test.pushStack2(9);
    
    // test.pushStack1(10);
    
    // test.pushStack2(9);
    
    TwoStackOptimal<int> test(size);
    
    test.pushFlexStack1(2);
    
    test.pushFlexStack2(9);
    
    test.pushFlexStack1(10);
    
    test.pushFlexStack2(4);
    
    test.pushFlexStack1(19);
    
    test.pushFlexStack2(7);
    
    cout << test.popFlexStack1() << endl;
    
    test.pushFlexStack1(44);
    
    // test.pushFlexStack1(99);
    
    // test.pushFlexStack2(16);
     
    test.display();
    
    return 0;
}